<?php

/**
 * Plugin Name: COCO's Custom Post Types and Taxonomies
 * Description: A simple plugin that adds custom post types and taxonomies
 * Version: 1.0
 * Author: Brian Yoo
 * License: GPL2
 */

function coco_posttypes() {

	// Event Post Types
	$labels = array(
		'name'								=> 'Events',
		'singular_name'				=> 'Event',
    'add_new_item'				=> 'Add New Event',
    'all_items'						=> 'All Events',
    'edit_item'						=> 'Edit Event',
		'menu_name'						=> 'Events',
		'new_item'						=> 'New Event',
    'not_found'						=> 'No events found.',
		'not_found_in_trash'	=> 'No events found in Trash.',
    'parent_item_colon'		=> 'Parent Event:',
    'search_items'				=> 'Search Events',
		'view_item'						=> 'View Event',
	);
	$args = array(
		'labels'								=> $labels,
		'capability_type'				=> 'post',
		'has_archive'						=> true,
		'hierarchical'					=> false,
		'menu_position'					=> 6,
		'menu_icon'							=> 'dashicons-calendar-alt',
		'public'								=> true,
		'publicly_queryable'		=> true,
		'query_var'							=> true,
		'rest_base'          		=> 'events',
    'rest_controller_class'	=> 'WP_REST_Posts_Controller',
		'rewrite'								=> array( 'slug' => 'events' ),
		'show_ui'								=> true,
		'show_in_menu'					=> true,
		'show_in_rest'					=> true,
		'supports'							=> array( 'title', 'author'  )
	);

	register_post_type( 'events', $args );

	// Photo Album Post Types
	$labels = array(
		'name'								=> 'Volunteers',
		'singular_name'				=> 'Volunteer',
    'add_new_item'				=> 'Add New Volunteer',
    'all_items'						=> 'All Volunteers',
    'edit_item'						=> 'Edit Volunteer',
		'menu_name'						=> 'Volunteers',
		'new_item'						=> 'New Volunteer',
    'not_found'						=> 'No volunteers found.',
		'not_found_in_trash'	=> 'No volunteers found in Trash.',
    'parent_item_colon'		=> 'Parent Volunteer:',
    'search_items'				=> 'Search Volunteers',
		'view_item'						=> 'View Volunteer',
	);
	$args = array(
		'labels'								=> $labels,
		'capabilities' => array(
		  'edit_post'          => 'none',
		  'read_post'          => 'update_core',
		  'delete_post'        => 'update_core',
		  'edit_posts'         => 'update_core',
		  'edit_others_posts'  => 'update_core',
		  'publish_posts'      => 'update_core',
		  'read_private_posts' => 'update_core',
		  'create_posts'       => 'none',
		),
		'capability_type'				=> 'post',
		'has_archive'						=> true,
		'hierarchical'					=> false,
		'menu_position'					=> 6,
		'menu_icon'							=> 'dashicons-groups',
		'public'								=> true,
		'publicly_queryable'		=> true,
		'query_var'							=> true,
		'rest_base'          		=> 'volunteers',
    'rest_controller_class'	=> 'WP_REST_Posts_Controller',
		'rewrite'								=> array( 'slug' => 'volunteers' ),
		'show_ui'								=> true,
		'show_in_menu'					=> true,
		'show_in_rest'					=> true,
		'supports'							=> array( 'title', 'editor'  )
	);

	register_post_type( 'volunteers', $args );

  // Alert Post Types
	$labels = array(
		'name'								=> 'Alerts',
		'singular_name'				=> 'Alert',
    'add_new_item'				=> 'Add New Alert',
    'all_items'						=> 'All Alerts',
    'edit_item'						=> 'Edit Alert',
		'menu_name'						=> 'Alerts',
		'new_item'						=> 'New Alert',
    'not_found'						=> 'No alerts found.',
		'not_found_in_trash'	=> 'No alerts found in Trash.',
    'parent_item_colon'		=> 'Parent Alert:',
    'search_items'				=> 'Search Alerts',
		'view_item'						=> 'View Alert',
	);
	$args = array(
		'labels'								=> $labels,
		'capability_type'				=> 'post',
		'has_archive'						=> true,
		'hierarchical'					=> false,
		'menu_position'					=> 6,
		'menu_icon'							=> 'dashicons-megaphone',
		'public'								=> true,
		'publicly_queryable'		=> true,
		'query_var'							=> true,
		'rest_base'          		=> 'alerts',
    'rest_controller_class'	=> 'WP_REST_Posts_Controller',
		'rewrite'								=> array( 'slug' => 'alerts' ),
		'show_ui'								=> true,
		'show_in_menu'					=> true,
		'show_in_rest'					=> true,
		'supports'							=> array( 'title', 'editor', 'thumbnail' )
	);

	register_post_type( 'alerts', $args );

}

add_action( 'init', 'coco_posttypes' );


function my_rewrite_flush() {
    // First, we "add" the custom post type via the above written function.
    // Note: "add" is written with quotes, as CPTs don't get added to the DB,
    // They are only referenced in the post_type column with a post entry,
    // when you add a post of this CPT.
    coco_posttypes();

    // ATTENTION: This is *only* done during plugin activation hook in this example!
    // You should *NEVER EVER* do this on every page load!!
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'my_rewrite_flush' );

?>
